# Dev Portfolio Template

Add more life to your CV with a clean dev portfolio website. The website is lightweight, fully responsive, and great for students. Just add your information and go. See live demo [here](https://dev-portfolio-template-motionlink.netlify.app).

## Notion Template

The Notion template for this website is available [here](https://oreal-motionlink.notion.site/Dev-Portfolio-https-github-com-bats64mgutsi-dev-portfolio-template-23f92b4bf64d49648ac065e6bbcd66a9). 

## Installation instructions

Instructions on how to install a Motionlink website can be found [here](https://motionlink.co/docs/Installing%20websites).
